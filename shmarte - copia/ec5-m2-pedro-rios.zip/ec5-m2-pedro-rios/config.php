<?php

// Especifico los parametros para la conexion con la BBDD user, root, el nombre de la bbdd
$db_user = "root";
$db_password = "";
$db_url="localhost";
$db_name="contactos";
 ?>
