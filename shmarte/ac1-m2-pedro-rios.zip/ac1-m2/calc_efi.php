<?php
// nota para mi libreris -pagina calc_efi.php -
function eficiente($cadena){
  $resul = eval('return '.$cadena.';');
return $resul;
}
?>
